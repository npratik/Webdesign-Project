

function callajaxfunction(url,dataToPopulate,totalDivData){
    $.ajax({
        url : url+'?'+dataToPopulate,
        type: 'GET',
        success : function(data){
			if(totalDivData != "entirePage"){
				$("#"+totalDivData+"").html(data);
			}else{
				document.write(data);
			}
			
		}
		
    })
}




function searchbyNumberfunc(){
	var formSerializeData = $("#checkFormNumber").serialize();
	callajaxfunction("lookupByNumber.jsp",formSerializeData,"newDivPlaced");
}



function gotoMainPage(){
	window.location.href='loggedin.jsp';
}
function gotoMainPage1(){
	callajaxfunction("loggedin.jsp",null,"entirePage");
}


